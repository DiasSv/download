create_makefile('-test-/load/protect')
