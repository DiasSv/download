void
Init_empty(void)
{
}
