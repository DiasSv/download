load File.join(File.dirname(__FILE__), "prepare_require.rb")

